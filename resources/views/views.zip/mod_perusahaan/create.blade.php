@extends ('layouts.admin_template')
  @section ('content')
<div class="box-header with-border">
  <h3 class="box-title">{{ $page_title }}</h3>
</div>
@include('layouts.errors')
@include('layouts.flash_message')
<form action="/tambah-perusahaan" method="post" enctype="multipart/form-data">
      {{ csrf_field() }}
      <div class="box box-default">
        <div class="box-body">
          <div class="row">
            <div class="col-md-12">

              <div class="form-group">
                <label>Nama Perusahaan</label>
                <input type="text" name="nama_perusahaan" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="nama">Jenis Perusahaan</label>
                 <select class="form-control select2" style="width: 50%;" name="kategori" required>
                  <option value="0">--pilih--</option>
                    @foreach($categories as $category)
                    <option value="{{$category->id}}">{{$category->nama_kategori}}</option>
                    @endforeach
                </select>
              </div>
              <div class="form-group">
                <label>Website ( jika ada )</label>
                <input type="text" name="website" class="form-control" required>
              </div>
              <div class="form-group">
                <label>Deskripsi Perusahaan</label>
<textarea class="textarea" name="deskripsi_perusahaan" style="width: 100%; height: 300px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" placeholder="jelaskan tentang perusahaan anda secara terperinci "></textarea>
              </div>
              <div class="form-group">
                <label>Alamat Perusahaan</label>
<textarea class="textarea" name="alamat_perusahaan" style="width: 100%; height: 300px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" placeholder="Isikan alamat perusahaan secara lengkap beserta informasi kontak yang dapat dihubungi "></textarea>
              </div>
              <div class="form-group">
                <label>Logo/Cover Perusahaan ( jika ada )</label>
                  <input type="file" name="gambar_cover">
              </div>
            </div>
      </div>
    <div class="box-footer text-center">
      <button type="button" class="btn btn-default" onclick="window.location.href='/semua-perusahaan'"><i class="fa fa-refresh"></i> Batal</button>
      <button type="submit" class="btn btn-info"><i class="fa fa-save"></i> Simpan</button>
    </div>
  </div>
</div>
</form> 
@endsection