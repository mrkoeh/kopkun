@extends ('layouts.admin_template')
  @section ('content')
<div class="box-header with-border">
  <h3 class="box-title">{{ $page_title }}</h3>
</div>
@include('layouts.errors')
@include('layouts.flash_message')
<form action="/ubah-perusahaan/{{$getcompany->id}}" method="post" enctype="multipart/form-data">
      {{ csrf_field() }}
      <div class="box box-default">
        <div class="box-body">
          <div class="row">
            <div class="col-md-12">

              <div class="form-group">
                <label>Nama Perusahaan</label>
                <input type="text" name="nama_perusahaan" class="form-control" value="{{$getcompany->nama_perusahaan}}">
              </div>
              <div class="form-group">
                <label for="nama">Jenis Perusahaan</label>
                 <select class="form-control select2" style="width: 50%;" name="kategori" required>
                  <option value="0">--pilih--</option>
                    @foreach($categories as $category)
                    <option value="{{$category->id}}" <?php if ($category->id == $getcompany->kategori_id) echo ' selected'; ?>>{{$category->nama_kategori}}</option>
                    @endforeach
                </select>
              </div>
              <div class="form-group">
                <label>Website ( jika ada )</label>
                <input type="text" name="website" class="form-control" value="{{$getcompany->website}}">
              </div>
              <div class="form-group">
                <label>Deskripsi Perusahaan</label>
<textarea class="textarea" name="deskripsi_perusahaan" style="width: 100%; height: 300px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" placeholder="jelaskan tentang perusahaan anda secara terperinci ">{{$getcompany->deskripsi_perusahaan}}</textarea>
              </div>
              <div class="form-group">
                <label>Alamat Perusahaan</label>
<textarea class="textarea" name="alamat_perusahaan" style="width: 100%; height: 300px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" placeholder="Isikan alamat perusahaan secara lengkap beserta informasi kontak yang dapat dihubungi ">{{$getcompany->alamat_perusahaan}}</textarea>
              </div>

              <div class="form-group">

                   @if($getcompany->gambar_cover == 0)
                  <img src="{{asset('uploads/noimage.png')}}" />
                  @else
                  <img src="{{ asset('uploads/place_cover/' . $getcompany->gambar_cover) }}"/>
                  @endif
              </div>
              <div class="form-group">
                <label>Ganti logo/cover</label>
                  <input type="file" name="gambar_cover">
              </div>
            </div>
      </div>
    <div class="box-footer text-center">
      <button type="button" class="btn btn-default" onclick="window.location.href='/semua-perusahaan'"><i class="fa fa-refresh"></i> Batal</button>
      <button type="submit" class="btn btn-info"><i class="fa fa-save"></i> Simpan</button>
    </div>
  </div>
</div>
</form> 
@endsection