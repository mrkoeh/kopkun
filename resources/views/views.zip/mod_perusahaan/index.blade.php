 @extends ('layouts.admin_template')
  @section ('content')
  <div class="box-header">
    <h3 class="box-title">{{ $page_title }}</h3>
  </div>
    @can('tambah_perusahaan')
    <button type="button" class="btn btn-info" onclick="window.location.href='/tambah-perusahaan'">
    <i class="fa fa-plus-square"></i> Tambah</button><br><br>
    @endcan
@include('layouts.errors')
@include('layouts.flash_message')     
<div class="box">
  <div class="box-body">
    <table id="example1" class="table table-bordered table-striped">
      <thead>
      <tr>
            <th>Nama</th>
            <th>Website</th>
            <th>Kategori</th>
            <th>Pengiklan</th>
            <th>Publish</th>
            <th></th>
      </tr>
      </thead>
      <tbody>
      @foreach($companys as $company)
      <tr>
        <td>{{$company->nama_perusahaan}}</td>
        <td>{{$company->website}}</td>
        <td>{{$company->created_user }}</td>
        <td>{{$company->nama_kategori}}</td>
      <td>
          @if($company->publish == 'Y' ) 
            <small class="label label-info">Publish</small>
          @else
            <small class="label label-warning">Pending</small> 
          @endif 
      </td>
        <td>
         @can('edit_perusahaan')  
          <button type="button" class="btn btn-xs btn-info" title="Edit Kategori" onclick="window.location.href='/ubah-perusahaan/{{$company->id}}'"><i class="fa fa-pencil-square-o"></i> Edit</button>
         @endcan
         @can('hapus_perusahaan')
          <button type="button" class="btn btn-xs btn-danger" title="Hapus Kategori" onclick="window.location.href='/hapus-perusahaan/{{$company->id}}'"><i class="fa fa-trash"></i> Hapus</button>
        @endcan   
        @can('ubah_status_perusahaan')
            <form method="post" action="{{url('/status-perusahaan', $company->id )}}">
              {{ csrf_field() }}
              <input type="hidden" name="publish" value="{{ $company->publish }}">
              <input type="hidden" name="id" value="{{ $company->id }}">
              <div class="btn-group-horizontal">
              @if($company->publish == 'Y')
              <button type="submit" class="btn btn-flat btn-xs text-danger">
                  <span class="glyphicon glyphicon-ban-circle"></span> Nonaktifkan
              </button>
              @elseif($company->publish == 'N')
              <button type="submit" class="btn btn-flat btn-xs text-green">
                  <span class="glyphicon glyphicon-ok-circle"></span> Aktifkan
              </button>
              @endif
              </div>
          </form>  
        @endcan
        </td>
      </tr>
      @endforeach
      </tbody>
    </table>
  </div>
</div>
@endsection