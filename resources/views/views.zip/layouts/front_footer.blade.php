<footer>
    <section class="cid-qMI4bymfZu" id="footer5-64">
        <div class="container">
            <div class="media-container-row">
                <div class="col-md-3">
                    <div class="media-wrap mbr-logo">
                        <a href="index.html">
                            <img src="{{asset('template/frontend/images/pedi-blue.png')}}" alt="PEDIHELP" title="">
                        </a>
                    </div>
                </div>
                <div class="col-md-9 mbr-text">
                    <p class="links mbr-fonts-style display-4"></p><br>
                    <a href="#" class="text-info display-4">Karir</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="#" class="text-info display-4">Tentang</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="#" class="text-info display-4">FAQ&nbsp;</a>&nbsp;
                    <a href="#" class="text-info display-4">Syarat &amp; Ketentuan</a>&nbsp;&nbsp;
                    <a href="#" class="text-info display-4">Kebijakan Privasi</a></p>
                    <p></p>
                </div>
            </div>
            <div class="footer-lower">
                <div class="media-container-row">
                    <div class="col-md-12">
                        <hr>
                    </div>
                </div>
                <div class="media-container-row mbr-white">
                    <div class="col-md-6 copyright">
                        <p class="mbr-text mbr-fonts-style display-2">
                            &copy; Copyright 2018 PT PEDIHELP Indonesia - All Rights Reserved
                        </p>
                    </div>
                    <div class="col-md-6">
                        <div class="social-list align-right">
                            <div class="soc-item">
                                <a href="https://twitter.com/pedihelp" target="_blank">
                                    <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon"></span>
                                </a>
                            </div>
                            <div class="soc-item">
                                <a href="https://www.facebook.com/pedihelp/" target="_blank">
                                    <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon"></span>
                                </a>
                            </div>
                            <div class="soc-item">
                                <a href="https://www.youtube.com/channel/pedihelp" target="_blank">
                                    <span class="mbr-iconfont mbr-iconfont-social socicon-youtube socicon"></span>
                                </a>
                            </div>
                            <div class="soc-item">
                                <a href="https://www.instagram.com/pedihelp/" target="_blank">
                                    <span class="mbr-iconfont mbr-iconfont-social socicon-instagram socicon"></span>
                                </a>
                            </div>
                            <div class="soc-item">
                                    <a href="https://www.linkedin.com/company/pedihelp/" target="_blank">
                                        <span class="mbr-iconfont mbr-iconfont-social socicon-linkedin socicon"></span>
                                    </a>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</footer>

<script src="{{asset('template/frontend/web/assets/jquery/jquery.min.js')}}"></script>
<script src="{{asset('template/frontend/popper/popper.min.js')}}"></script>
<script src="{{asset('template/frontend/tether/tether.min.js')}}"></script>
<script src="{{asset('template/frontend/bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('template/frontend/dropdown/js/script.min.js')}}"></script>
<script src="{{asset('template/frontend/touchswipe/jquery.touch-swipe.min.js')}}"></script>
<script src="{{asset('template/frontend/viewportchecker/jquery.viewportchecker.js')}}"></script>
<script src="{{asset('template/frontend/vimeoplayer/jquery.mb.vimeo_player.js')}}"></script>
<script src="{{asset('template/frontend/smoothscroll/smooth-scroll.js')}}"></script>
<script src="{{asset('template/frontend/bootstrapcarouselswipe/bootstrap-carousel-swipe.js')}}"></script>
<script src="{{asset('template/frontend/mbr-popup-btns/mbr-popup-btns.js')}}"></script>
<script src="{{asset('template/frontend/mbr-testimonials-slider/mbr-testimonials-slider.js')}}"></script>
<script src="{{asset('template/frontend/parallax/jarallax.min.js')}}"></script>
<script src="{{asset('template/frontend/ytplayer/jquery.mb.ytplayer.min.js')}}"></script>
<script src="{{asset('template/frontend/theme/js/script.js')}}"></script>
<script src="{{asset('template/frontend/slidervideo/script.js')}}"></script>


<div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a class="icon-icon_arrow_up"></a></div>

<input name="animation" type="hidden">