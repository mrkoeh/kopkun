@extends('layouts.front_template')

@section('content')

<section class="mbr-section content5 cid-qLBLv2e5aG mbr-parallax-background" id="content5-28">
    <div class="mbr-overlay" style="opacity: 0.7; background-color: rgb(0, 0, 0);"></div>
    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
                <h2 class="align-center mbr-bold mbr-white pb-3 mbr-fonts-style display-1">Buat Proyek</h2>
            </div>
        </div>
    </div>
</section>

<section class="features18 popup-btn-cards cid-qMIamfi4LL" id="features18-67">
    <div class="container">
        <form class="form-ad" method="post" action="{{url('/posting-lowongan')}}" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="form-group">
                <label class="control-label">Judul Proyek <span>(padat singkat)</span></label>
                <input type="text" class="form-control" name="judul" required="required">
            </div>
            <div class="form-group">
                <label class="control-label">Jenis Proyek</label>
                <select class="form-control select2" style="width: 100%;" name="role" required="">
                    @foreach($jenis as $r)
                    <option value="{{$r->tipe_slug}}">{{$r->nama_tipe}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label class="control-label">Wilayah</label>
                <select class="form-control select2" style="width: 100%;" name="role" required="">
                    @foreach($area as $a)
                        <option value="{{$a->area_slug}}">{{$a->nama_area}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label class="control-label">Pendidikan</label>
                <select class="form-control select2" style="width: 100%;" name="role" required="">
                    @foreach($pendidikan as $p)
                        <option value="{{$p->pendidikan_slug}}">{{$p->nama_pendidikan}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label class="control-label">Waktu Kerja</label>
                <select class="form-control select2" style="width: 100%;" name="role" required="">
                    @foreach($waktu as $w)
                        <option value="{{$w->id}}">{{$w->nama_waktu}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label class="control-label">Jabatan</label>
                <select class="form-control select2" style="width: 100%;" name="role" required="">
                    @foreach($level as $l)
                        <option value="{{$l->id}}">{{$l->nama_level}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label class="control-label">Status Pegawai</label>
                <select class="form-control select2" style="width: 100%;" name="role" required="">
                    @foreach($status as $s)
                        <option value="{{$s->id}}">{{$s->nama_status}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label class="control-label">Deskripsi Proyek</label>
                <textarea id="konten" name="deskripsi_lowongan" style="width: 100%; height: 400px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" placeholder="jelaskan tentang perusahaan, cara melamar, syarat untuk melamar dan informasi kontak" required="required"></textarea>
            </div>
            <div class="form-group">
                <label class="control-label">Keahlian yang dibutuhkan</label>
                <input type="text" class="form-control" name="judul" required="required">
            </div>
            <div class="form-group">
                <label class="control-label">Foto</label>
                <input type="file" name="cover_lowongan">
            </div>
            <div class="form-group">
                <label class="control-label">File</label>
                <input type="file" name="cover_lowongan">
            </div>
            <button type="submit" class="btn btn-common">Submit</button>
        </form>
    </div>
</section>

@endsection

@section('pagescript')

@endsection