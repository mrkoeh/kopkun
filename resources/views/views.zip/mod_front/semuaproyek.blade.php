@extends('layouts.front_template')

@section('content')

<section class="mbr-section content5 cid-qLBLv2e5aG mbr-parallax-background" id="content5-28">
    <div class="mbr-overlay" style="opacity: 0.7; background-color: rgb(0, 0, 0);"></div>
    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
                <h2 class="align-center mbr-bold mbr-white pb-3 mbr-fonts-style display-1">Semua Proyek</h2>
            </div>
        </div>
    </div>
</section>

<section class="features18 popup-btn-cards cid-qMIamfi4LL" id="features18-67">
    <div class="container">
    	<div class="media-container-row pt-6 ">
	        <form class="form-ad" method="post" action="{{url('/posting-lowongan')}}" enctype="multipart/form-data">
	            {{ csrf_field() }}
	            <div class="form-group">
	                <label class="control-label">Judul Proyek</label>
	                <input type="text" class="form-control" name="judul" required="required">
	            </div>
	            <button type="submit" class="btn btn-common">cari</button>
	        </form>
	    </div>
        <div class="media-container-row pt-5 ">
            <div class="card p-4 col-12 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center">
                            <a href="#" class="btn btn-white display-4">Detail</a>
                        </div>
                        <img src="{{asset('template/frontend/images/renovasi.png')}}" alt="PEDIHELP" title="">
                    </div>
                    <div class="card-box">
                    	<b>Pembangunan RUmah</b><br>
                        <p class="mbr-text mbr-fonts-style align-left display-7">
                            setup toko ukuran 3x4 <strong>Rp 8.000.000</strong> dengan waktu <strong>2 minggu
                            </strong></p>
                    </div>
                </div>
            </div>
            <div class="card p-4 col-12 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center">
                            <a href="#" class="btn btn-white display-4">Detail</a>
                        </div>
                        <img src="{{asset('template/frontend/images/renovasi.png')}}" alt="PEDIHELP" title="">
                    </div>
                    <div class="card-box">
                    	<b>Pembangunan RUmah</b><br>
                        <p class="mbr-text mbr-fonts-style align-left display-7">
                            setup toko ukuran 3x4 <strong>Rp 8.000.000</strong> dengan waktu <strong>2 minggu
                            </strong></p>
                    </div>
                </div>
            </div>
            <div class="card p-4 col-12 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center">
                            <a href="#" class="btn btn-white display-4">Detail</a>
                        </div>
                        <img src="{{asset('template/frontend/images/renovasi.png')}}" alt="PEDIHELP" title="">
                    </div>
                    <div class="card-box">
                    	<b>Pembangunan RUmah</b><br>
                        <p class="mbr-text mbr-fonts-style align-left display-7">
                            setup toko ukuran 3x4 <strong>Rp 8.000.000</strong> dengan waktu <strong>2 minggu
                            </strong></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="media-container-row pt-5 ">
            <div class="card p-3 col-12 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center">
                            <a href="#" class="btn btn-white display-4">Selengkapnya</a>
                        </div>
                        <img src="{{asset('template/frontend/images/renovasi.png')}}" alt="PEDIHELP" title="">
                    </div>
                </div>
            </div>
            <div class="card p-3 col-12 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center">
                            <a href="#" class="btn btn-white display-4">Selengkapnya</a>
                        </div>
                        <img src="{{asset('template/frontend/images/kebersihan.png')}}" alt="PEDIHELP" title="">
                    </div>
                </div>
            </div>
            <div class="card p-3 col-12 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center">
                            <a href="#" class="btn btn-white display-4">Selengkapnya</a>
                        </div>
                        <img src="{{asset('template/frontend/images/perbantuan.png')}}" alt="PEDIHELP" title="">
                    </div>
                </div>
            </div>
            <div class="card p-3 col-12 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center">
                            <a href="#" class="btn btn-white display-4">Selengkapnya</a>
                        </div>
                        <img src="{{asset('template/frontend/images/renovasi.png')}}" alt="PEDIHELP" title="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection