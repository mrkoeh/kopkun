<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table>
		<tr><td>Nama</td><td>:</td><td>{{$name}}</td></tr>
		<tr><td>Email</td><td>:</td><td>{{$email}}</td></tr>
		<tr><td>Subjek</td><td>:</td><td>{{$subject}}</td></tr>
		<tr><td>Pesan</td><td>:</td><td>{{$pesan}}</td></tr>
	</table>
</body>
</html>
