@extends('layouts.front_template')

@section('content')

<section class="mbr-section content5 cid-qLBLv2e5aG mbr-parallax-background" id="content5-28">
    <div class="mbr-overlay" style="opacity: 0.7; background-color: rgb(0, 0, 0);"></div>
    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
                <h2 class="align-center mbr-bold mbr-white pb-3 mbr-fonts-style display-1">Tentang Pedihelp</h2>
            </div>
        </div>
    </div>
</section>

<section class="mbr-section article content1 cid-qMI0PQEaDY" id="content1-63">
    <div class="container">
        <div class="media-container-row">
            <div class="mbr-text col-12 col-md-8 mbr-fonts-style display-7">
                <strong>PEDIHELP</strong> PediHelp diinisiasi pada September 2017 di Purwokerto. Berawal dari sekolompok tukang becak yang kesulitan mendapat penghasilan, kami menginisiasi layanan jasa kebersihan bagi tukang becak agar mendapat penghasilan tambahan.
                <br><br>
                Mimpi besar PediHelp dimasa yang akan datang adalah mengkaryakan para pekerja informal agar lebih berdaya saing dan profesional. Anggota kami berasal dari tukang becak, tukang,  kuli bangunan, tukang tambal, tukang kunci, dan tukang pijat.
                <br><br>
                Saat ini PediHelp diinkubasi oleh Kopkun Institute (kopkuninstitute.org) dan menjadi bagian dari  Kopkun Coop Incorporated (kopkun.com), grup koperasi yang menaungi beberapa koperasi hasil pemekaran lainnya.
            </div>
        </div>
    </div>
</section>



@endsection

@section('pagescript')

@endsection